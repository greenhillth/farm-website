import{l as o,a as r}from"../chunks/C_XJ_A0c.js";export{o as load_css,r as start};
