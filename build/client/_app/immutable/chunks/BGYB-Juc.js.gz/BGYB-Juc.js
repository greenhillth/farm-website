import{aQ as a}from"./B5Olihw7.js";a();
