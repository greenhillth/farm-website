import{av as a}from"./C0ys7KY4.js";a();
