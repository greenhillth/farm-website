import{aO as a}from"./D3hnq5Lw.js";a();
